let imgl;
let isImageClicked = false;

function preload() {
  img = loadImage('in.jpg'); // Imagem
  img = loadImage('cafe.jpg'); // Imagem
}
function setup() {
  createCanvas(500, 500);
}
function draw() {
  background(255);

  if (!isImageClicked) {
    // Exibe a imagem 
    image(img, width / 2 - img.width / 2, height / 2 - img.height / 2);
  } else {
    // Quando a imagem for clicada, esconde a imagem e exibe outra imagem
  }
}
function mousePressed() {
  // Detecta se a imagem foi clicada
  let imgX = width / 2 - img.width / 2;
  let imgY = height / 2 - img.height / 2;
  let imgW = img.width;
  let imgH = img.height;
  
  if (mouseX > imgX && mouseX < imgX + imgW && mouseY > imgY && mouseY < imgY + imgH) {
    // Se a imagem for clicada,começa a outra imagem
    isImageClicked = true;
  }
}
